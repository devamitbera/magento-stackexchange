<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace StackExchanges\Magento\Plugin\Frontend\Magento\Theme\Block\Html;

class Pager
{

    public function afterGetAvailableLimit(
        \Magento\Theme\Block\Html\Pager $subject,
        $result
    ) {
      if ($subject->getRequest()->getFullActionName() !== 'sales_order_history'){
          return $result;
      }
        return [7 => 7, 20 => 20, 50 => 50];
    }
}
