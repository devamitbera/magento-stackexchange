<?php
namespace Cjp\Homepagesearch\Plugin\FormPlugin;

class Form
{

    public function afterGetSearchPostUrl(
        \Magento\CatalogSearch\Block\Advanced\Form $subject,
        $result
    ) {
        return $subject->getUrl('catalogsearch/advanced/result');
    }
}
